<!-- jQuery -->
<script src="<?=base_url('assets/')?>js/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?=base_url('assets/')?>js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?=base_url('assets/')?>js/metisMenu.min.js"></script>

<!-- Custom Theme JavaScript -->
<script src="<?=base_url('assets/')?>js/startmin.js"></script>

</body>
</html>